AFGHAN-TURK MEDICINE GUIDE — ANDROID STUDIO PROJECT

This is an Android Studio project wrapper around the included medicine guide HTML. It opens inside an Android app window, not as a Chrome tab.

BUILD THE APK
1. On a Windows computer, install Android Studio from the official site:
   https://developer.android.com/studio
2. Extract this ZIP into a normal folder, for example Desktop\AfghanTurkMedicineAndroidProject.
3. Open Android Studio > Open, then choose the extracted AfghanTurkMedicineAndroidProject folder (the one containing settings.gradle.kts).
4. Wait for Gradle sync. If asked, install Android SDK Platform 35 and accept the required licenses.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build completes, click "locate" in the notification. The APK is normally:
   app\build\outputs\apk\debug\app-debug.apk
7. Copy app-debug.apk to your Android phone (USB, email, or another trusted transfer method).
8. On the phone, tap the APK and allow "Install unknown apps" for the file manager/browser if Android asks. Only install APKs you built and trust.

CAMERA / PHOTO NOTES
- The app can choose/upload a medicine-package photo through Android's file chooser. The HTML uses the Tesseract.js OCR library from a CDN, so printed-text reading needs internet access on first use and while the CDN library is fetched.
- The current wrapper intentionally does not enable broad file access or automatically grant WebView camera permissions.
- Camera capture behavior can vary by Android version/WebView. If the file chooser offers Camera, use it; otherwise take a photo with the phone camera app first and choose it from Photos.
- This starter is not yet a polished Play Store release. Test it on your device before relying on it.

GOOGLE SHEETS
- Built-in medicine entries work without Google Sheets.
- Google Sheets is optional. To use it, follow the separate README_SETUP.txt instructions and connect your Apps Script endpoint. Do not put patient information in the sheet.

MEDICAL SAFETY
This is an educational reference, not a diagnostic or prescribing tool. Have a licensed pharmacist/doctor verify medicine entries. OCR can misread medicine names; confirm the printed generic name and strength. Never use the app to identify loose pills or choose a dose.
