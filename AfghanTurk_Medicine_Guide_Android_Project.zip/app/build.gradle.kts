plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.afghanturkschool.medicineguide"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.afghanturkschool.medicineguide"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
