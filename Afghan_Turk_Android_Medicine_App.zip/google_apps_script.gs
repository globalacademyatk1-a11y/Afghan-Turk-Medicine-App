/**
 * Afghan-Turk Medicine Guide — Google Sheets data endpoint
 * SETUP:
 * 1. Import medicines_google_sheet_template.csv into a Google Sheet.
 * 2. Keep the first row headings exactly as in the template.
 * 3. In Extensions > Apps Script, paste this entire file.
 * 4. Deploy > New deployment > Web app. Execute as: Me.
 * 5. Access: anyone with the link only if school policy allows; the sheet should contain no patient data.
 * 6. Copy the deployed /exec URL. In the app, set it in the setup instructions below.
 */
function doGet(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  const values = sheet.getDataRange().getDisplayValues();
  const rows = values.slice(1).filter(r => r[0]).map(r => ({
    name: r[0], generic: r[1], uses: r[2], safety: r[3]
  }));
  const payload = JSON.stringify(rows);
  const callback = e && e.parameter && e.parameter.callback;
  if (callback && /^[A-Za-z_$][0-9A-Za-z_$]*$/.test(callback)) {
    return ContentService.createTextOutput(callback + '(' + payload + ');')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(payload)
    .setMimeType(ContentService.MimeType.JSON);
}
