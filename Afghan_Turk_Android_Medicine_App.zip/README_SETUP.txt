AFGHAN-TUR MAARIF BOYS HIGHSCHOOL — MEDICINE GUIDE (ANDROID)

WHAT THIS IS
A phone-friendly web app that can be installed on an Android home screen after hosting. It searches a starter list of 25 medicines, can use the phone camera or upload a medicine-package photo, and uses browser OCR (Tesseract.js) to read printed English text. It can load medicine entries from a Google Sheet through Apps Script.

IMPORTANT: It does not provide diagnosis or dosing. OCR can misread labels; users must confirm the printed medicine name and strength. It is not designed to identify loose pills. Have a licensed pharmacist/doctor verify the database before public use.

FILES
- index.html: app interface and code
- manifest.json: installable web-app metadata
- sw.js: basic caching
- medicines_google_sheet_template.csv: 25 rows to import into Sheets
- google_apps_script.gs: Google Sheets endpoint
- README_SETUP.txt: this guide

STEP A — CREATE GOOGLE SHEET
1. Open Google Sheets and create a blank spreadsheet.
2. File > Import > Upload, then choose medicines_google_sheet_template.csv.
3. Import into a new sheet. Keep these four header columns:
   Medicine Name | Generic Name | Common Uses | Important Safety Information
4. Edit/add records as needed, but have a qualified healthcare professional review all medical content.

STEP B — PUBLISH THE SHEET READ ENDPOINT
1. In that Sheet choose Extensions > Apps Script.
2. Replace the editor contents with google_apps_script.gs and save.
3. Deploy > New deployment > select type "Web app".
4. Execute as: Me. Access setting: choose the narrowest option compatible with your school's needs. "Anyone" makes the read endpoint public; do not include patient data.
5. Deploy and authorize. Copy the web app URL ending in /exec.

STEP C — CONNECT THE SHEET TO THE APP
In index.html, find this line:
  const endpoint=localStorage.getItem('medicineSheetEndpoint');
Replace it with:
  const endpoint='PASTE_YOUR_WEB_APP_EXEC_URL_HERE';
Keep the quotation marks. Save. This uses JSONP for cross-origin browser access.

STEP D — HOST THE APP (HTTPS REQUIRED FOR CAMERA)
Upload index.html, manifest.json and sw.js together to a static HTTPS host approved by your school (for example, a school web server or a static hosting service). Do not just open the file locally: camera access generally needs HTTPS or localhost. The OCR library is loaded from a CDN, so first use needs an internet connection.

STEP E — INSTALL ON ANDROID
1. Open the hosted HTTPS app URL in Chrome on Android.
2. Open Chrome menu (three dots) > "Install app" or "Add to Home screen".
3. Allow camera permission when prompted.
4. Test searching and scanning using a medicine box with a large, clear printed label.

TROUBLESHOOTING
- Camera won't open: use HTTPS, grant Chrome camera permission, or use the upload button.
- OCR fails: improve light, avoid glare, hold steady, capture the printed brand/generic name; confirm the result.
- Sheet doesn't load: check the /exec URL, deployment access, exact headers and internet connection. The built-in list remains available.
- Android app install missing: open the HTTPS site in Chrome; hosting must serve manifest.json and sw.js.

SAFETY
This is a starter prototype, not a regulated medicine reference. Do not rely on it to decide treatment or dose. Confirm ingredients/strength and consult a pharmacist/doctor. Antibiotics require prescription. Seek urgent care for severe symptoms.
